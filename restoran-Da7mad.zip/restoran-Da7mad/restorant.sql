-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 28, 2021 at 06:46 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restorant`
--

-- --------------------------------------------------------

--
-- Table structure for table `categprie`
--

CREATE TABLE `categprie` (
  `idcategorie` int(11) NOT NULL,
  `categorie` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categprie`
--

INSERT INTO `categprie` (`idcategorie`, `categorie`) VALUES
(1, 'Breakfast'),
(2, 'Launch'),
(3, 'dinner');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `idnews` int(11) NOT NULL,
  `titre` text,
  `soustitre` text,
  `descri` text,
  `image` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`idnews`, `titre`, `soustitre`, `descri`, `image`, `date`) VALUES
(7, 'Welcome to Restoran', 'DA7MAD est un restaurantDA7MAD est un restaurant', '<p>DA7MAD est un restaurant se situant sur le Boulevard Haussmann, &agrave; seulement deux pas de la place Vend&ocirc;me, des Galeries Lafayette et de l&#39;Op&eacute;ra Garnier. Que ce soit entre amis, en couple ou en famille, cette brasserie pleine de charme sera l&#39;endroit id&eacute;al pour chaque occasion.</p>\r\n\r\n<p>Les menus sont ouverts sur le monde avec pas moins de 6 langues traduites, afin de vous recevoir dans votre langue natale et dans les meilleures conditions.</p>\r\n\r\n<p>Des menus vegan friendly sont &eacute;galement propos&eacute;s pour satisfaire toutes les envies.</p>\r\n', '15 - Copy.jpg', '2021-12-21'),
(8, 'abayou', 'MoHAMMED asBAYOU', '<p>AAAAAAAAAAAAAAAA</p>\r\n', 'blog1.jpg', '2021-12-22'),
(9, 'Welcome to Restoran', 'DA7MAD est un restaurant', '<p>qqqqqqqqqqqqqqqqqqq</p>\r\n', 'img2.jpg', '2021-12-23'),
(10, 'Anniversaire', 'les fÃ©te des anniversaires', '<ul>\r\n	<li>&laquo;&nbsp;Les diverses coutumes que l&#39;on observe aujourd&#39;hui lors des anniversaires de naissance ont une longue histoire. Leurs origines sont li&eacute;es &agrave; la magie et &agrave; la religion. Les pratiques en usage dans les temps anciens, qui consistaient &agrave; adresser des f&eacute;licitations, &agrave; offrir des&nbsp;<a href=\"https://fr.wikipedia.org/wiki/Cadeau\">cadeaux</a>&nbsp;et &agrave; f&ecirc;ter l&#39;&eacute;v&eacute;nement &mdash; des&nbsp;<a href=\"https://fr.wikipedia.org/wiki/Bougie\">bougies</a>&nbsp;allum&eacute;es venant couronner le tout &mdash; &eacute;taient cens&eacute;es prot&eacute;ger des&nbsp;<a href=\"https://fr.wikipedia.org/wiki/D%C3%A9mon_(esprit)\">d&eacute;mons</a>&nbsp;celui qui c&eacute;l&eacute;brait son anniversaire&nbsp;; on assurait ainsi sa s&eacute;curit&eacute; pour l&#39;ann&eacute;e &agrave; venir. (&hellip;) Jusqu&#39;au&nbsp;ive&nbsp;si&egrave;cle, le&nbsp;<a href=\"https://fr.wikipedia.org/wiki/Christianisme\">christianisme</a>&nbsp;a rejet&eacute; la c&eacute;l&eacute;bration des anniversaires, les consid&eacute;rant comme une coutume&nbsp;<a href=\"https://fr.wikipedia.org/wiki/Pa%C3%AFen\">pa&iuml;enne</a>.&nbsp;&raquo;&nbsp;<a href=\"https://fr.wikipedia.org/wiki/Anniversaire#cite_note-5\">5</a></li>\r\n</ul>\r\n\r\n<ul>\r\n	<li>Dans l&#39;<a href=\"https://fr.wikipedia.org/wiki/Ancien_Testament\">Ancien Testament</a>, un festin d&#39;anniversaire est cit&eacute; en&nbsp;<em>Gen&egrave;se</em>&nbsp;40, 20, dans l&#39;histoire de&nbsp;<a href=\"https://fr.wikipedia.org/wiki/Joseph_(fils_de_Jacob)\">Joseph</a>&nbsp;: &quot;<em>Et il arriva, le troisi&egrave;me jour,&nbsp;</em>jour de la naissance<em>&nbsp;du Pharaon, qu&rsquo;il fit un festin &agrave; tous ses serviteurs&nbsp;; et il &eacute;leva la t&ecirc;te du chef des &eacute;chansons et la t&ecirc;te du chef des panetiers au milieu de ses serviteurs&nbsp;: il le r&eacute;tablit dans son office d&rsquo;&eacute;chanson</em>(...).&nbsp;<em>Mais le chef des panetiers, il le pendit.&rdquo;</em></li>\r\n	<li>Dans le&nbsp;<a href=\"https://fr.wikipedia.org/wiki/Nouveau_Testament\">Nouveau Testament</a>, un festin d&#39;anniversaire est cit&eacute; en&nbsp;<em>Marc</em>&nbsp;6, 21 quand la fille d&#39;<a href=\"https://fr.wikipedia.org/wiki/H%C3%A9rodiade\">H&eacute;rodiade</a>&nbsp;obtient la t&ecirc;te de&nbsp;<a href=\"https://fr.wikipedia.org/wiki/Jean_le_Baptiste\">Jean le Baptiste</a>&nbsp;: &ldquo;<em>Or vint un jour propice, quand H&eacute;rode,&nbsp;</em>&agrave; l&rsquo;anniversaire de sa naissance<em>, fit un banquet pour les grands de sa cour, les officiers et les principaux personnages de la Galil&eacute;e&nbsp;: - la fille d&rsquo;H&eacute;rodiade entra et dansa, et</em>&nbsp;<em>plut tant &agrave; H&eacute;rode qu&rsquo;il promit avec serment de lui donner ce qu&rsquo;elle demanderait. Et elle de dire, endoctrin&eacute;e par sa m&egrave;re: &lsquo;Donne-moi ici, sur un plat, la t&ecirc;te de Jean le Baptiste.&rsquo; (...) il envoya d&eacute;capiter Jean dans la prison.&rdquo;</em></li>\r\n</ul>\r\n\r\n<ul>\r\n	<li>&laquo;&nbsp;Les&nbsp;<a href=\"https://fr.wikipedia.org/wiki/Gr%C3%A8ce_antique\">Grecs</a>&nbsp;croyaient qu&#39;&agrave; chaque humain s&#39;attachait un esprit protecteur ou&nbsp;<em>daim&ocirc;n</em>&nbsp;qui assistait &agrave; sa naissance et veillait sur lui durant sa vie. Cet esprit &eacute;tait en relation mystique avec le dieu dont l&#39;anniversaire correspondait au jour de naissance de l&#39;individu. Les&nbsp;<a href=\"https://fr.wikipedia.org/wiki/Rome_antique\">Romains</a>&nbsp;aussi souscrivaient &agrave; cette id&eacute;e. (...) Cette croyance a fait son chemin et se retrouve dans les notions d&#39;<a href=\"https://fr.wikipedia.org/wiki/Ange_gardien\">ange gardien</a>, de marraine f&eacute;e et de&nbsp;<a href=\"https://fr.wikipedia.org/wiki/Saint_patron\">saint patron</a>. (...) La coutume consistant &agrave; allumer des bougies sur les g&acirc;teaux a commenc&eacute; avec les Grecs. (...) Des g&acirc;teaux de miel, ronds comme la lune et &eacute;clair&eacute;s par des cierges, &eacute;taient d&eacute;pos&eacute;s sur les autels du temple de&nbsp;<a href=\"https://fr.wikipedia.org/wiki/Diane_(mythologie)\">Diane</a>. (...) La croyance populaire attribue aux bougies d&#39;anniversaire le pouvoir magique d&#39;exaucer les souhaits. (...) Les cierges allum&eacute;s et les feux sacrificiels ont toujours eu une signification mystique particuli&egrave;re depuis que l&#39;homme a commenc&eacute; &agrave; dresser des autels &agrave; ses dieux. Les bougies sont donc un hommage &agrave; l&#39;enfant qui f&ecirc;te son anniversaire; elles lui font honneur et lui portent chance. (...) Les souhaits d&#39;anniversaire et les v&oelig;ux de bonheur font partie int&eacute;grante de la f&ecirc;te. (...) Cette croyance prend ses racines dans la magie. (...) Les souhaits d&#39;anniversaire peuvent faire du bien ou du mal parce que l&#39;on est plus proche du monde des esprits &agrave; ce moment pr&eacute;cis.&nbsp;&raquo;</li>\r\n</ul>\r\n', 'service1.jpg', '2021-12-24');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `idrese` int(11) NOT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `prenom` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `nmtele` int(20) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `heure` int(11) DEFAULT NULL,
  `cmbper` int(11) DEFAULT NULL,
  `commentaire` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`idrese`, `nom`, `prenom`, `email`, `nmtele`, `date`, `heure`, `cmbper`, `commentaire`) VALUES
(1, 'Mohamed', 'Mohamed', '0', 620187775, '0000-00-00', 10, 10, 'sssssssssssssssssss'),
(3, 'Mohamed', 'Mohamed', '0', 620187775, '2021-12-30', 10, 10, '5555555555555555555qqqqqqqqqqqq'),
(4, 'Mohamed', 'Mohamed', '0', 620187775, '2021-12-29', 10, 11, 'jgggggggggggggggggigg'),
(6, 'aaaa', 'aaaaa', '0', 620187775, '2021-12-22', 10, 1, 'jjjj'),
(7, 'Mohamed', 'Mohamed', 'ImagineCreative@gmail.com', 620187775, '2021-12-23', 11, 2, 'qqqqqqqq');

-- --------------------------------------------------------

--
-- Table structure for table `souscategorie`
--

CREATE TABLE `souscategorie` (
  `idsouscategire` int(11) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `categie` varchar(255) NOT NULL,
  `soustitre` varchar(255) NOT NULL,
  `prix` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `souscategorie`
--

INSERT INTO `souscategorie` (`idsouscategire`, `titre`, `categie`, `soustitre`, `prix`, `image`, `date`) VALUES
(1, 'Tacos Poulet', 'Breakfast', 'Viande', 55, 'some-feature1.png', '2021-12-24'),
(3, 'Artilcle', 'Launch', 'DA7MAD est un restaurant', 220, 'a1.jpg', '2021-12-24'),
(5, 'Chiken Nuget', 'Launch', 'Chiken Nuget Chiken Nuget Chiken Nuget', 150, 'img5.jpg', '2021-12-24'),
(6, 'Artilcle', 'Dinner\r\n', 'DA7MAD est un restaurantDA7MAD est un restaurantq', 10, 'close.png', '2021-12-24'),
(7, 'aaaaaaaaaaaaaaa', 'Dinner\r\n', 'aaaaaaaa', 100, '11.jpg', '2021-12-24'),
(8, 'ddfdf', 'dinner', 'sssssssssssssss', 220, '15 - Copy.jpg', '2021-12-24'),
(9, 'Riad', 'Launch', 'Riad tacos', 1000, 'about-md.jpg', '2021-12-28');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `images` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categprie`
--
ALTER TABLE `categprie`
  ADD PRIMARY KEY (`idcategorie`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`idnews`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`idrese`);

--
-- Indexes for table `souscategorie`
--
ALTER TABLE `souscategorie`
  ADD PRIMARY KEY (`idsouscategire`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categprie`
--
ALTER TABLE `categprie`
  MODIFY `idcategorie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `idnews` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `idrese` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `souscategorie`
--
ALTER TABLE `souscategorie`
  MODIFY `idsouscategire` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
