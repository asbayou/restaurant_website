<?php
require('cnx.php');
$conn = Database::connect();

$userid = $_POST['userid'];

$sql = "select * from reservation where idrese=" . $userid;
$stmt = $conn->query($sql);
while ($row = $stmt->fetch()) {
?>
    <table border='0' width='100%'>
        <tr>

            <td>
                <p>Nom : <?php echo $row['nom']; ?></p>
                <p>Prenom : <?php echo $row['prenom']; ?></p>
                <p>Email : <?php echo $row['email']; ?></p>
                <p>Numero telephone : <?php echo $row['nmtele']; ?></p>
                <p>date : <?php echo $row['date']; ?></p>
                <p>L'heure : <?php echo $row['heure']; ?></p>
                <p>Combien personne : <?php echo $row['cmbper']; ?></p>
                <p> commentaire : <?php echo $row['commentaire']; ?></p>
            </td>
        </tr>
    </table>

<?php } ?>