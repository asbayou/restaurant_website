<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <?php
    require('cnx.php');
    $test = $_GET['id'];
    $conn = Database::connect();
    $sql = "DELETE FROM reservation WHERE idrese= ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$test]);
    header('location:index.php');
    if (!$stmt) {
        echo "<script>alert('Error ');</script>";
    }




    ?>





</body>

</html>