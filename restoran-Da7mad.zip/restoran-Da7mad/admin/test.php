<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>CKEditor 5 – Document editor</title>
    <script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>
</head>

<body>
    <h1>Document editor</h1>

    <!-- The toolbar will be rendered in this container. -->
    <div id="toolbar-container"></div>

    <!-- This container will become the editable. -->
    <form action="" method="POST">

        <textarea name="editor1"></textarea>
        <script>
            CKEDITOR.replace('editor1');
        </script>

        </div>
        <button name="submit" type="submit" class="btn btn-primary">Submit</button>
    </form>
    <?php
    require('cnx.php');
    $conn = Database::connect();

    if (isset($_POST['submit'])) {
        $s = addslashes($_POST['editor1']);

        $sql = "INSERT INTO `text` VALUES (0,?)";
        $stmt = $conn->prepare($sql);
        $stmt->execute(array($s));
        if ($stmt) {
            echo "Bien Fait";
        } else {
            echo "Errooor";
        }
    }


    ?>
    <script src="https://cdn.ckeditor.com/[version.number]/[distribution]/ckeditor.js"></script>

</body>

</html>